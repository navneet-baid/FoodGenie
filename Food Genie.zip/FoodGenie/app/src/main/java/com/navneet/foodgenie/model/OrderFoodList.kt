package com.navneet.foodgenie.model

data class OrderFoodList(
    val food_item_id: String,
    val name: String,
    val cost: String,
)
