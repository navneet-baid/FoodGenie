package com.navneet.foodgenie.model

data class Restaurants(
    val resaturant_id: String,
    val resaturant_name: String,
    val rating: String,
    val cost_for_one: String,
    val image: String
)