package com.navneet.foodgenie.model

data class foodItemId(val food_item_id: String)